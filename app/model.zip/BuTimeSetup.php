<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BuTimeSetup extends Model
{
    protected $table = 'bu_time_setups';
	protected $primaryKey = 'id';
}
