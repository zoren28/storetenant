<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdSuggestion extends Model
{
    //
}
