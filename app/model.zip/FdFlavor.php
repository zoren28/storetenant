<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdFlavor extends Model
{
    protected $guarded = [];
}
