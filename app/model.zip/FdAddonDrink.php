<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdAddonDrink extends Model
{
    protected $guarded = [];
}
