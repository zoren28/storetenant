<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PickUpSchedule extends Model
{
    protected $guarded=[];
}
