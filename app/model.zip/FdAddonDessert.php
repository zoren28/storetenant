<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdAddonDessert extends Model
{
    protected $guarded = [];
}
