<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdSubMenu extends Model
{
    //
}
