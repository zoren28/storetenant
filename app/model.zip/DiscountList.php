<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscountList extends Model
{
    protected $table = 'discount_lists';
	protected $primaryKey = 'id';
}
