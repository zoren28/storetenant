<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdCategory extends Model
{
    protected $guarded=[];
}
