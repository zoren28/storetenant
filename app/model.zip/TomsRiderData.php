<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TomsRiderData extends Model
{
    protected $table = 'toms_riders_data';
    protected $primaryKey = 'id';
    protected $guarded=[];
}
