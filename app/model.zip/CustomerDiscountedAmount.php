<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerDiscountedAmount extends Model
{
    protected $guarded = [];
}
