<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdRemittanceDetail extends Model
{
    protected $guarded=[];
}
