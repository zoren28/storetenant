<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdCookingWay extends Model
{
    protected $guarded = [];
}
