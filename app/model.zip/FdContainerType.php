<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdContainerType extends Model
{
    protected $guarded = [];
}
