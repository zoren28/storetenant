<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdContainerTypeDetail extends Model
{
    protected $guarded = [];
}
