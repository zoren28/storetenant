<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FdAddonSide extends Model
{
    protected $guarded = [];
}
