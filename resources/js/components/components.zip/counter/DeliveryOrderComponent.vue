<template>
    <span class="badge badge-danger rounded-circle noti-icon-badge">
        {{Object.keys($root.getDeliveryOrders).length}}
    </span>
</template>
<script>
export default {
    
}
</script>