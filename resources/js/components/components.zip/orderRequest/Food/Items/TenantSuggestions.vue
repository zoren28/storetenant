<template>
  <div></div>
</template>

<script>
/** @format */

export default {
  props: {
    tenantSuggestions: {
      type: Array
    }
  }
}
</script>